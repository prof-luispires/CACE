CMARL Expert v7.4 - Reliability-Aware Confidence Fusion

Protocol:
- 50% train / 20% validation / 30% independent test.
- Expert thresholds selected on train only.
- Expert reliability estimated on validation only.
- Test set is never used for tuning.
- Reliability:
  r_i = 0.35*max(MCC_i,0) + 0.25*F1_i + 0.20*EDR_i + 0.20*(1-FPR_i)
- Reliability weights are normalized across the four experts.
- Coordinator and weighted-vote thresholds are selected on validation only.
- Final reporting uses five seeds (42, 123, 321, 777, 999), nine sensors,
  and Low/Medium/High anomaly-load scenarios.
