CMARL Expert v7.2 — audited true expert cooperation
====================================================
Key methodological changes:
1. True anomaly-specialized expert action spaces are used (spike, drift, flat, dropout).
2. Each expert candidate detector is evaluated on TRAIN only; detector rewards form softmax weights used to create an expert confidence score.
3. Expert thresholds are selected on TRAIN with explicit FPR penalty.
4. Coordinator is fitted on TRAIN and its decision threshold is selected on VALIDATION only.
5. Final metrics are reported on the independent TEST partition only (50/20/30 temporal split).
6. Confidence-hybrid fusion combines the calibrated coordinator with high-confidence two-expert agreement.
7. Realistic anomaly-load profiles were defined: Low ~5%, Medium ~10%, High ~18-20% effective global point prevalence.

Validated multi-seed experiment included in this package:
Medium profile, seeds 42, 123, 321, 777, 999; 9 sensors; 45 sensor-seed test pairs.

Main result (macro over 45 pairs):
Confidence Hybrid: F1 0.3200, Precision 0.4169, Recall 0.3560, FPR 0.0488, MCC 0.2974.
Single-Agent RL: F1 0.2378, Precision 0.3727, Recall 0.2599, FPR 0.0500, MCC 0.2158.
Paired F1 gain: +0.0822 (+34.56% relative); Wilcoxon p=0.000685.

Important limitation:
Spike expert is strong (F1 ~0.794) and dropout is useful (F1 ~0.371), but drift remains weak pointwise (F1 ~0.022). This is partly because an injected gradual drift is labelled across its complete ramp while a causal detector generally identifies it only after sufficient accumulation. Event-level detection/delay should therefore be added rather than claiming strong pointwise drift classification.
