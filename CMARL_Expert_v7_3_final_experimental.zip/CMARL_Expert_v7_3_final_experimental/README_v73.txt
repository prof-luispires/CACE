CMARL Expert v7.3 — final experimental audit
==============================================
Dataset: real environmental temperature, humidity, light; 9 sensor nodes.
Protocol: temporal 50/20/30 train/validation/test; 5 seeds (42,123,321,777,999).
Anomaly-load profiles: Low ~4.83%, Medium ~9.57%, High ~17.98% global point prevalence.
Final metrics are computed on TEST only.

Main macro F1 results over 45 sensor-seed pairs per scenario:
LOW: Hybrid 0.2088 vs Single-Agent 0.1559 (+33.93%, Wilcoxon p=0.00638); Hybrid ~ Majority (p=0.488).
MEDIUM: Hybrid 0.3200 vs Single-Agent 0.2378 (+34.56%, p=0.000685); vs Majority +22.71% (p=0.000751); vs OR-all not significant (p=0.324).
HIGH: Hybrid 0.4246 vs Single-Agent 0.3607 (+17.71%, p=0.0689, not significant); vs Majority +50.83% (p<1e-7); vs OR-all +20.69% (p=0.0157).

Event-level findings:
- Drift pointwise F1 remains weak, but event detection is 0.57/0.61/0.90 for Low/Medium/High.
- Dropout event detection is 0.81/1.00/1.00.
- Spike remains strongest pointwise expert (F1 0.67/0.79/0.78).
- Flat-line remains moderate/weak pointwise but improves at event level.

Ablation warning:
Removing Drift slightly improves F1 in Medium (0.3214 vs 0.3200) and High (0.4259 vs 0.4246), while slightly reducing Low. Therefore, current evidence does NOT support claiming that every expert independently improves global F1. Drift should be framed as useful for event-level coverage, or redesigned before a strong per-expert contribution claim.
