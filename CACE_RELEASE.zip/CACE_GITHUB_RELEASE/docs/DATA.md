# Experimental data

The large canonical CSV archive is excluded from this Git-ready package.

For local/Raspberry Pi reproduction, use the canonical 135-case dataset archive produced by the experimental pipeline and place it where expected by the RP5 batch scripts.

The 135 cases correspond to the fixed sensor × seed × anomaly-load experimental design used by the study. Preserve the chronological TRAIN/VALIDATION/TEST roles when reproducing the experiments.
