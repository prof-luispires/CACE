#!/usr/bin/env python3
"""CACE fixed statistical detector library (no RL/MARL code)."""
from __future__ import annotations
import numpy as np
import pandas as pd

VARIABLES=["temp_c","humidity_avg","light_avg"]
EXPERTS=["spike","drift","flat","dropout"]

def _series(df,v):
    return pd.to_numeric(df[v],errors='coerce').interpolate(limit=3,limit_area='inside').ffill(limit=1).bfill(limit=1)

def rolling_median_flags(x,window=21,k=3.0):
    half=window//2; med=x.rolling(window,center=True,min_periods=half).median(); mad=(x-med).abs().rolling(window,center=True,min_periods=half).median(); sigma=1.4826*mad.replace(0,np.nan)
    return ((x-med).abs()>k*sigma).fillna(False).astype(int).to_numpy()

def rolling_z_flags(x,window=21,thr=3.0):
    half=window//2; mu=x.rolling(window,center=True,min_periods=half).mean(); sd=x.rolling(window,center=True,min_periods=half).std(ddof=0).replace(0,np.nan)
    return (((x-mu).abs()/sd)>thr).fillna(False).astype(int).to_numpy()

def diff_z_flags(x,window=21,thr=3.0): return rolling_z_flags(x.diff().fillna(0.0),window,thr)
def ewma_residual_flags(x,span=24,window=48,thr=2.5):
    r=(x-x.ewm(span=span,adjust=False).mean()).abs(); half=max(3,window//2); mu=r.rolling(window,center=True,min_periods=half).mean(); sd=r.rolling(window,center=True,min_periods=half).std(ddof=0).replace(0,np.nan)
    return (((r-mu)/sd)>thr).fillna(False).astype(int).to_numpy()
def slope_flags(x,window=36,thr=2.2):
    s=((x-x.shift(window))/max(window,1)).fillna(0.0).abs(); return rolling_z_flags(s,max(21,window),thr)
def mean_shift_flags(x,short=12,long=72,thr=2.0):
    s=x.rolling(short,min_periods=max(3,short//2)).mean(); l=x.rolling(long,min_periods=max(6,long//2)).mean(); return rolling_z_flags((s-l).abs().fillna(0.0),long,thr)
def flat_std_flags(x,window=18,quantile=.035):
    sd=x.rolling(window,center=True,min_periods=max(3,window//2)).std(ddof=0); diff=x.diff().abs().rolling(window,center=True,min_periods=max(3,window//2)).mean(); st=float(sd.quantile(quantile)) if sd.notna().any() else 0.; dt=float(diff.quantile(quantile)) if diff.notna().any() else 0.
    return ((sd<=st)&(diff<=dt)).fillna(False).astype(int).to_numpy()
def low_range_flags(x,window=24,quantile=.045):
    hi=x.rolling(window,center=True,min_periods=max(3,window//2)).max(); lo=x.rolling(window,center=True,min_periods=max(3,window//2)).min(); r=hi-lo; t=float(r.quantile(quantile)) if r.notna().any() else 0.; return (r<=t).fillna(False).astype(int).to_numpy()
def dropout_flags(x,window=12,fraction=.85):
    d=x.diff().abs().fillna(0.0); nz=d<=max(1e-6,float(d.quantile(.02))); run=nz.rolling(window,center=True,min_periods=max(3,window//2)).mean(); return (run>fraction).fillna(False).astype(int).to_numpy()
def multivar_or(df,func,**kwargs):
    f=[func(_series(df,v),**kwargs) for v in VARIABLES if v in df.columns]; return np.maximum.reduce(f).astype(int) if f else np.zeros(len(df),int)

ACTION_LIBRARY={
'hampel_w21_k3':lambda d:multivar_or(d,rolling_median_flags,window=21,k=3.0),'hampel_w31_k2.5':lambda d:multivar_or(d,rolling_median_flags,window=31,k=2.5),'z_w21_t3':lambda d:multivar_or(d,rolling_z_flags,window=21,thr=3.0),'diffz_w21_t3':lambda d:multivar_or(d,diff_z_flags,window=21,thr=3.0),
'ewma_s24_w48_t2.5':lambda d:multivar_or(d,ewma_residual_flags,span=24,window=48,thr=2.5),'ewma_s48_w96_t2.2':lambda d:multivar_or(d,ewma_residual_flags,span=48,window=96,thr=2.2),'slope_w36_t2.2':lambda d:multivar_or(d,slope_flags,window=36,thr=2.2),'mean_shift_12_72':lambda d:multivar_or(d,mean_shift_flags,short=12,long=72,thr=2.0),
'flat_std_w18':lambda d:multivar_or(d,flat_std_flags,window=18,quantile=.035),'flat_std_w36':lambda d:multivar_or(d,flat_std_flags,window=36,quantile=.045),'low_range_w24':lambda d:multivar_or(d,low_range_flags,window=24,quantile=.045),'dropout_w12':lambda d:multivar_or(d,dropout_flags,window=12,fraction=.85),'dropout_w24':lambda d:multivar_or(d,dropout_flags,window=24,fraction=.85)}
EXPERT_ACTIONS={'spike':['hampel_w21_k3','hampel_w31_k2.5','z_w21_t3','diffz_w21_t3'],'drift':['ewma_s24_w48_t2.5','ewma_s48_w96_t2.2','slope_w36_t2.2','mean_shift_12_72'],'flat':['flat_std_w18','flat_std_w36','low_range_w24','dropout_w12'],'dropout':['dropout_w12','dropout_w24','flat_std_w18','low_range_w24']}
SINGLE_ACTIONS=list(ACTION_LIBRARY)
