# Raspberry Pi 5 benchmark

Target platform: Raspberry Pi 5 (8 GB), 64-bit Raspberry Pi OS.

## Preparation

Copy the benchmark folder and the canonical data archive to the Raspberry Pi 5. From this directory:

```bash
chmod +x *.sh
./INSTALL_RP5.sh
./RUN_QUICK_TEST.sh
```

If the quick test completes successfully, run:

```bash
./RUN_STANDARD.sh
```

The full 135-case benchmark can subsequently be executed with:

```bash
./RUN_FULL_135.sh
```

Do not use TEST results to retune the frozen CACE configuration.
