#!/usr/bin/env python3
from pathlib import Path
import argparse, subprocess, sys, zipfile, tempfile, json, platform
import pandas as pd
ROOT=Path(__file__).resolve().parents[1]
ZIP=ROOT/'CACE_CANONICAL_135_CSV.zip'; EXPERT=ROOT/'config'/'cace_expert_configuration.csv'; COORD=ROOT/'config'/'cace_coordinator_stability.csv'; OUT=ROOT/'outputs'
SENSORS=['501','502','505','506','507','508','509','510','511']; SEEDS=[42,123,321,777,999]; LOADS=['low','medium','high']

def cases(mode):
    if mode=='quick': return [(x,42,'509') for x in LOADS]
    if mode=='standard': return [(x,42,s) for x in LOADS for s in SENSORS]
    return [(x,z,s) for x in LOADS for z in SEEDS for s in SENSORS]

def main():
    p=argparse.ArgumentParser(); p.add_argument('--mode',choices=['quick','standard','full'],default='standard'); p.add_argument('--runs',type=int,default=30); p.add_argument('--warmup',type=int,default=5); a=p.parse_args()
    OUT.mkdir(exist_ok=True); summaries=[]; all_cases=cases(a.mode); first_meta=None
    with zipfile.ZipFile(ZIP) as z, tempfile.TemporaryDirectory() as td:
      td=Path(td)
      for i,(load,seed,sensor) in enumerate(all_cases,1):
        member=f'CACE_CANONICAL_DATA/{load}/seed_{seed}/sensor_{sensor}_multivar_labeled.csv'
        print(f'[{i}/{len(all_cases)}] {load} seed={seed} sensor={sensor}',flush=True)
        z.extract(member,td); csv=td/member; out=OUT/f'rp5_{load}_seed{seed}_sensor{sensor}.csv'
        cmd=[sys.executable,str(ROOT/'code'/'rp5_benchmark.py'),'--csv',str(csv),'--expert-config',str(EXPERT),'--coord-config',str(COORD),'--sensor',sensor,'--scenario',load,'--seed',str(seed),'--runs',str(a.runs),'--warmup',str(a.warmup),'--out',str(out)]
        subprocess.run(cmd,check=True)
        d=pd.read_csv(out); meta=json.loads(out.with_suffix('.json').read_text(encoding='utf-8')); first_meta=first_meta or meta
        for m,g in d.groupby('mode'):
          summaries.append(dict(scenario=load,seed=seed,sensor=sensor,mode=m,n_samples=int(g.n_samples.iloc[0]),runs=len(g),
            wall_s_mean=g.wall_s.mean(),wall_s_std=g.wall_s.std(),wall_s_median=g.wall_s.median(),ms_per_sample_mean=g.ms_per_sample.mean(),ms_per_sample_std=g.ms_per_sample.std(),
            samples_per_s_mean=g.samples_per_s.mean(),samples_per_s_std=g.samples_per_s.std(),peak_rss_mib_mean=g.peak_rss_mib.mean(),peak_rss_mib_max=g.peak_rss_mib.max(),
            cpu_one_core_pct_mean=g.cpu_one_core_pct.mean(),cpu_total_capacity_pct_mean=g.cpu_total_capacity_pct.mean(),temp_start_c_mean=g.temp_start_c.mean(),temp_end_c_mean=g.temp_end_c.mean(),temp_end_c_max=g.temp_end_c.max(),
            throttling_observed=bool(g.throttling_observed.fillna(False).any())))
        csv.unlink(missing_ok=True)
    summary=pd.DataFrame(summaries); summary.to_csv(OUT/f'RP5_SUMMARY_{a.mode.upper()}.csv',index=False)
    if first_meta:
        lines=['CACE Raspberry Pi 5 benchmark - system information','================================================','']
        for k,v in first_meta.items():
            if k not in {'sensor','scenario','seed','n_samples'}: lines.append(f'{k}: {v}')
        lines += ['',f'batch_mode: {a.mode}',f'cases: {len(all_cases)}',f'timed_runs_per_mode_per_case: {a.runs}',f'warmups_per_mode_per_case: {a.warmup}']
        (OUT/'RP5_SYSTEM_INFO.txt').write_text('\n'.join(lines)+'\n',encoding='utf-8')
    print('\nDONE. CSV files are in:',OUT)
if __name__=='__main__': main()
