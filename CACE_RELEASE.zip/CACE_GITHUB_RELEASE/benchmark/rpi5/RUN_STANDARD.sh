#!/bin/bash
set -e
cd "$(dirname "$0")"
python3 code/run_rp5_batch.py --mode standard --runs 30 --warmup 5
read -p "Finished. Press Enter to close."
