#!/usr/bin/env python3
"""Raspberry Pi 5 benchmark of the frozen CACE inference pipeline; no fitting/calibration."""
from __future__ import annotations
import argparse, json, platform, subprocess, threading, time
from pathlib import Path
import numpy as np, pandas as pd, psutil
import cace_detectors as det


def temp_c():
    p=Path('/sys/class/thermal/thermal_zone0/temp')
    try: return float(p.read_text().strip())/1000.0
    except Exception: return float('nan')


def throttled_raw():
    try:
        s=subprocess.check_output(['vcgencmd','get_throttled'], text=True, stderr=subprocess.DEVNULL, timeout=2).strip()
        return s.split('=',1)[1] if '=' in s else s
    except Exception:
        return 'unavailable'


def throttled_active(raw):
    if raw == 'unavailable': return None
    try: return int(raw,16) != 0
    except Exception: return None


def pkg_version(name):
    try:
        from importlib.metadata import version
        return version(name)
    except Exception: return 'unknown'


def system_info():
    info={
        'platform': platform.platform(), 'machine': platform.machine(),
        'python': platform.python_version(), 'numpy': pkg_version('numpy'),
        'pandas': pkg_version('pandas'), 'psutil': pkg_version('psutil'),
        'cpu_logical': psutil.cpu_count(logical=True), 'cpu_physical': psutil.cpu_count(logical=False),
        'ram_gib': psutil.virtual_memory().total/2**30, 'temperature_c': temp_c(),
        'throttled': throttled_raw(), 'energy_measured': False,
    }
    for path,key in [('/proc/device-tree/model','device_model'),('/etc/os-release','os_release')]:
        try: info[key]=Path(path).read_text(errors='replace').replace('\x00','').strip()
        except Exception: info[key]='unavailable'
    return info


def load_cfg(expert_csv,coord_csv,sensor,scenario,seed):
    e=pd.read_csv(expert_csv); c=pd.read_csv(coord_csv)
    e=e[(e.sensor==sensor)&(e.scenario==scenario)&(e.seed==seed)]
    c=c[(c.sensor==sensor)&(c.scenario==scenario)&(c.seed==seed)&(c['mode'].eq('drift_only'))]
    if len(e)!=4 or len(c)!=1: raise ValueError('Frozen configuration not uniquely found for requested sensor/scenario/seed')
    return e,c.iloc[0]


def frozen_predict(df,econf,cc):
    C=[]
    for expert in det.EXPERTS:
        r=econf[econf.expert==expert].iloc[0]; weights=json.loads(r.weights); acts=det.EXPERT_ACTIONS[expert]
        A=np.column_stack([det.ACTION_LIBRARY[a](df) for a in acts]).astype(float)
        w=np.array([weights[a] for a in acts]); C.append(A@w)
    C=np.column_stack(C); j=det.EXPERTS.index('drift'); rel=float(cc['reliability_drift']); alpha=.60
    C[:,j]*=alpha+(1-alpha)*rel
    coef=np.array([float(cc[f'coef_{e}']) for e in det.EXPERTS]); intercept=float(cc.coord_intercept)
    z=intercept+C@coef; score=1/(1+np.exp(-np.clip(z,-60,60)))
    cp=(score>=float(cc.coord_threshold)).astype(int)
    gate=((C>=float(cc.high_conf)).sum(1)>=int(cc.min_agree)).astype(int)
    return np.maximum(cp,gate)


def measure(fn,n,mode,run):
    proc=psutil.Process(); logical=max(psutil.cpu_count(logical=True) or 1,1)
    rss0=proc.memory_info().rss; cpu0=proc.cpu_times(); t0=temp_c(); thr0=throttled_raw()
    peak=[rss0]; stop=threading.Event()
    def sample_mem():
        while not stop.is_set():
            try: peak[0]=max(peak[0],proc.memory_info().rss)
            except Exception: pass
            stop.wait(0.01)
    th=threading.Thread(target=sample_mem,daemon=True); th.start()
    st=time.perf_counter()
    try: fn()
    finally:
        elapsed=time.perf_counter()-st; stop.set(); th.join(timeout=.2)
    cpu1=proc.cpu_times(); rss1=proc.memory_info().rss; t1=temp_c(); thr1=throttled_raw()
    cpu_time=(cpu1.user+cpu1.system)-(cpu0.user+cpu0.system)
    cpu_one_core_pct=100.0*cpu_time/elapsed if elapsed>0 else float('nan')
    return dict(
        mode=mode,run=run,n_samples=n,wall_s=elapsed,ms_per_sample=1000*elapsed/n,samples_per_s=n/elapsed,
        rss_start_mib=rss0/2**20,rss_end_mib=rss1/2**20,peak_rss_mib=peak[0]/2**20,
        peak_rss_delta_mib=(peak[0]-rss0)/2**20,cpu_time_s=cpu_time,
        cpu_one_core_pct=cpu_one_core_pct,cpu_total_capacity_pct=cpu_one_core_pct/logical,
        temp_start_c=t0,temp_end_c=t1,throttled_start=thr0,throttled_end=thr1,
        throttling_observed=bool(throttled_active(thr0) or throttled_active(thr1)) if throttled_active(thr0) is not None and throttled_active(thr1) is not None else None)


def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--csv',required=True); ap.add_argument('--expert-config',required=True); ap.add_argument('--coord-config',required=True)
    ap.add_argument('--sensor',required=True); ap.add_argument('--scenario',required=True,choices=['low','medium','high']); ap.add_argument('--seed',required=True,type=int)
    ap.add_argument('--runs',type=int,default=30); ap.add_argument('--warmup',type=int,default=5); ap.add_argument('--out',default='rp5_benchmark.csv'); a=ap.parse_args()
    econf,cc=load_cfg(a.expert_config,a.coord_config,a.sensor,a.scenario,a.seed); pre=pd.read_csv(a.csv); pre.columns=[c.lower() for c in pre]; n=len(pre)
    def infer(): return frozen_predict(pre,econf,cc)
    def e2e():
        d=pd.read_csv(a.csv); d.columns=[c.lower() for c in d]; return frozen_predict(d,econf,cc)
    for _ in range(a.warmup): infer(); e2e()
    rows=[]
    for i in range(a.runs): rows += [measure(infer,n,'inference_only',i+1),measure(e2e,n,'end_to_end',i+1)]
    d=pd.DataFrame(rows); d.to_csv(a.out,index=False)
    meta=system_info(); meta.update(runs=a.runs,warmup=a.warmup,sensor=a.sensor,scenario=a.scenario,seed=a.seed,n_samples=n)
    Path(a.out).with_suffix('.json').write_text(json.dumps(meta,indent=2),encoding='utf-8')
    cols=['wall_s','ms_per_sample','samples_per_s','peak_rss_mib','cpu_one_core_pct','cpu_total_capacity_pct','temp_end_c']
    print(d.groupby('mode')[cols].agg(['mean','std','median']))

if __name__=='__main__': main()
