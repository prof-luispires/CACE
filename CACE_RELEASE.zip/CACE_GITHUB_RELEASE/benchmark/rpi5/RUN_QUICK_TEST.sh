#!/bin/bash
set -e
cd "$(dirname "$0")"
python3 code/run_rp5_batch.py --mode quick --runs 5 --warmup 2
read -p "Finished. Press Enter to close."
