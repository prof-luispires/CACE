#!/bin/bash
set -e
cd "$(dirname "$0")"
echo "Installing CACE RP5 requirements..."
python3 -m pip install --user -r code/requirements_rp5.txt
echo "Done."
